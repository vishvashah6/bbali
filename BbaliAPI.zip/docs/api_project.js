define({
  "name": "ridesharing-test",
  "version": "0.0.0",
  "description": "",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-07-19T13:39:36.044Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
